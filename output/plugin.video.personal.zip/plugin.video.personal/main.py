# main.py
# Personal Kodi Add-on - v1.3.0
# Movies / Series / Anime / Live TV + Clean Title + Dual System Tokens

import sys
import urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])

BASE_URL = "https://user-manager-lime.vercel.app"

# ==============================================================================
# CHANGED: Replaced single hardcoded USER_KEY with dual system tokens
# ==============================================================================
TOKEN_LIGHT = "123kodi123token123friend_light"
TOKEN_HEAVY = "123kodi123token123everything"

# NOTE: Skin forcing functions (force_skin_once, TARGET_SKIN_ID, FIRST_RUN_FLAG) 
# were removed. OpenWizard handles skin, Arial Hebrew fonts, and language 
# settings seamlessly when restoring backups.


def get_active_token():
    """
    CHANGED: Dynamically selects the system token based on the add-on setting.
    Reads from resources/settings.xml ('0' = Light System, '1' = Heavy System).
    """
    profile_choice = ADDON.getSetting("system_profile")
    if profile_choice == "1":
        return TOKEN_HEAVY
    return TOKEN_LIGHT


def build_url(query):
    return sys.argv[0] + "?" + urllib.parse.urlencode(query)


def get_params():
    param_string = sys.argv[2][1:]
    return dict(urllib.parse.parse_qsl(param_string))


def show_error(msg):
    xbmcgui.Dialog().notification("Personal", msg, xbmcgui.NOTIFICATION_ERROR)


def list_root():
    xbmcplugin.setContent(ADDON_HANDLE, "files")
    categories = [
        ("סרטים", "movie"),
        ("סדרות", "series"),
        ("אנימה", "anime"),
        ("שידור חי", "tv")
    ]
    for label, content_type in categories:
        list_item = xbmcgui.ListItem(label=label)
        list_item.setIsFolder(True)
        url = build_url({"action": "type_root", "type": content_type})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_live_tv():
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    # CHANGED: Uses get_active_token() instead of static USER_KEY
    url = BASE_URL + "/api/kodi-catalog?userKey=" + get_active_token() + "&list=live_channels"
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
    except Exception as e:
        show_error("שגיאת חיבור: " + str(e))
        return

    for item in data.get("items", []):
        list_item = xbmcgui.ListItem(label=item["title"])
        list_item.setArt({"poster": item.get("poster", ""), "fanart": item.get("fanart", "")})
        list_item.setProperty("IsPlayable", "true")
        url_to_streams = build_url({
            "action": "streams",
            "type": "tv",
            "imdb_id": item.get("imdb_id", item["title"]),
            "title": item["title"]
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url_to_streams, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_type_root(content_type):
    xbmcplugin.setContent(ADDON_HANDLE, "files")
    # CHANGED: Uses get_active_token() instead of static USER_KEY
    url = BASE_URL + "/api/kodi-catalog?userKey=" + get_active_token() + "&list=catalogs"
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
    except Exception as e:
        show_error("שגיאת חיבור: " + str(e))
        return

    matching = [c for c in data.get("catalogs", []) if c["type"] == content_type]
    if not matching:
        show_error("לא נמצאו קטלוגים לסוג הזה")

    for cat in matching:
        list_item = xbmcgui.ListItem(label=cat["name"])
        list_item.setIsFolder(True)
        url_to_catalog = build_url({
            "action": "catalog",
            "type": cat["type"],
            "catalogId": cat["id"]
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url_to_catalog, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_catalog_items(catalog_type, catalog_id):
    xbmcplugin.setContent(ADDON_HANDLE, "movies" if catalog_type == "movie" else "tvshows")
    # CHANGED: Uses get_active_token() instead of static USER_KEY
    url = BASE_URL + "/api/kodi-catalog?userKey=" + get_active_token() + "&type=" + catalog_type + "&catalogId=" + catalog_id
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
    except Exception as e:
        show_error("שגיאת חיבור: " + str(e))
        return

    for item in data.get("items", []):
        list_item = xbmcgui.ListItem(label=item["title"])
        list_item.setArt({"poster": item.get("poster", ""), "fanart": item.get("fanart", "")})
        list_item.setInfo("video", {
            "title": item["title"],
            "plot": item.get("plot", ""),
            "year": item.get("year", ""),
            "genre": item.get("genres", "")
        })
        if item.get("imdb_id"):
            list_item.setUniqueIDs({"imdb": item["imdb_id"]}, "imdb")

        url_to_streams = build_url({
            "action": "streams",
            "type": item["type"],
            "imdb_id": item["imdb_id"],
            "title": item["title"]
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url_to_streams, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_streams(video_type, imdb_id, clean_title):
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    # CHANGED: Uses get_active_token() instead of static USER_KEY
    url = BASE_URL + "/api/kodi?userKey=" + get_active_token() + "&imdb_id=" + imdb_id + "&type=" + video_type
    try:
        # CHANGED: Increased timeout from 15s to 25s to prevent premature timeouts during Debrid link resolution
        resp = requests.get(url, timeout=25)
        data = resp.json()
    except Exception as e:
        show_error("שגיאת חיבור: " + str(e))
        return

    for stream in data.get("results", []):
        source_hint = stream.get("title", "")[:35]
        label = "[" + stream.get("quality", "SD") + "] " + clean_title
        if stream.get("sizeGB"):
            label += " (" + str(stream["sizeGB"]) + " GB)"

        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo("video", {"title": clean_title, "plot": source_hint})
        list_item.setUniqueIDs({"imdb": imdb_id}, "imdb")
        list_item.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            stream["url"],
            list_item,
            isFolder=False
        )

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def router():
    # REMOVED: force_skin_once() call removed from here to prevent skin switching glitches
    params = get_params()
    action = params.get("action")

    if action == "type_root":
        if params["type"] == "tv":
            list_live_tv()
        else:
            list_type_root(params["type"])
    elif action == "catalog":
        list_catalog_items(params["type"], params["catalogId"])
    elif action == "streams":
        list_streams(params["type"], params["imdb_id"], params.get("title", "תוצאה"))
    else:
        list_root()


if __name__ == "__main__":
    router()