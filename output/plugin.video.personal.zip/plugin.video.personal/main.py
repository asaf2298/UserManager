# main.py
# Personal Kodi Add-on - v1.2.0
# חלוקה ל-Movies / Series / Anime / Live TV + Clean Title + Force Skin
import sys
import os
import urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
ADDON_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
FIRST_RUN_FLAG = os.path.join(ADDON_PROFILE, "skin_forced.flag")

TARGET_SKIN_ID = "skin.arctic.horizon.2"  # שנה כאן אם תרצה Skin אחר

BASE_URL = "https://user-manager-lime.vercel.app"
USER_KEY = "1c1.....c7bb"  # <-- מזהה המשתמש שלך


def is_skin_installed(skin_id):
    query = '{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","id":1,"params":{"addonid":"%s","properties":["enabled"]}}' % skin_id
    result = xbmc.executeJSONRPC(query)
    return "error" not in result


def force_skin_once():
    """מפעיל את ה-Skin המבוקש בהפעלה הראשונה בלבד, בתנאי שהוא מותקן."""
    if xbmcvfs.exists(FIRST_RUN_FLAG):
        return

    if not xbmcvfs.exists(ADDON_PROFILE):
        xbmcvfs.mkdirs(ADDON_PROFILE)

    if is_skin_installed(TARGET_SKIN_ID):
        set_query = (
            '{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,'
            '"params":{"setting":"lookandfeel.skin","value":"%s"}}'
        ) % TARGET_SKIN_ID
        xbmc.executeJSONRPC(set_query)
        xbmcgui.Dialog().notification("Personal", "הוחל סקין Arctic Horizon 2", xbmcgui.NOTIFICATION_INFO, 4000)
    else:
        xbmcgui.Dialog().notification(
            "Personal",
            "מומלץ להתקין Arctic Horizon 2 מה-Repository לתמיכה טובה בעברית",
            xbmcgui.NOTIFICATION_WARNING, 6000
        )

    f = xbmcvfs.File(FIRST_RUN_FLAG, "w")
    f.write("done")
    f.close()


def build_url(query):
    return sys.argv[0] + "?" + urllib.parse.urlencode(query)


def get_params():
    param_string = sys.argv[2][1:]
    return dict(urllib.parse.parse_qsl(param_string))


def show_error(msg):
    xbmcgui.Dialog().notification("Personal", msg, xbmcgui.NOTIFICATION_ERROR)


def list_root():
    xbmcplugin.setContent(ADDON_HANDLE, "files")
    categories = [
        ("סרטים", "movie"),
        ("סדרות", "series"),
        ("אנימה", "anime"),
        ("שידור חי", "tv")
    ]
    for label, content_type in categories:
        list_item = xbmcgui.ListItem(label=label)
        list_item.setIsFolder(True)
        url = build_url({"action": "type_root", "type": content_type})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_live_tv():
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    url = BASE_URL + "/api/kodi-catalog?userKey=" + USER_KEY + "&list=live_channels"
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
    except Exception as e:
        show_error("שגיאת חיבור: " + str(e))
        return

    for item in data.get("items", []):
        list_item = xbmcgui.ListItem(label=item["title"])
        list_item.setArt({"poster": item.get("poster", ""), "fanart": item.get("fanart", "")})
        list_item.setProperty("IsPlayable", "true")
        url_to_streams = build_url({
            "action": "streams",
            "type": "tv",
            "imdb_id": item.get("imdb_id", item["title"]),
            "title": item["title"]
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url_to_streams, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_type_root(content_type):
    xbmcplugin.setContent(ADDON_HANDLE, "files")
    url = BASE_URL + "/api/kodi-catalog?userKey=" + USER_KEY + "&list=catalogs"
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
    except Exception as e:
        show_error("שגיאת חיבור: " + str(e))
        return

    matching = [c for c in data.get("catalogs", []) if c["type"] == content_type]
    if not matching:
        show_error("לא נמצאו קטלוגים לסוג הזה")

    for cat in matching:
        list_item = xbmcgui.ListItem(label=cat["name"])
        list_item.setIsFolder(True)
        url_to_catalog = build_url({
            "action": "catalog",
            "type": cat["type"],
            "catalogId": cat["id"]
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url_to_catalog, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_catalog_items(catalog_type, catalog_id):
    xbmcplugin.setContent(ADDON_HANDLE, "movies" if catalog_type == "movie" else "tvshows")
    url = BASE_URL + "/api/kodi-catalog?userKey=" + USER_KEY + "&type=" + catalog_type + "&catalogId=" + catalog_id
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
    except Exception as e:
        show_error("שגיאת חיבור: " + str(e))
        return

    for item in data.get("items", []):
        list_item = xbmcgui.ListItem(label=item["title"])
        list_item.setArt({"poster": item.get("poster", ""), "fanart": item.get("fanart", "")})
        list_item.setInfo("video", {
            "title": item["title"],
            "plot": item.get("plot", ""),
            "year": item.get("year", ""),
            "genre": item.get("genres", "")
        })
        if item.get("imdb_id"):
            list_item.setUniqueIDs({"imdb": item["imdb_id"]}, "imdb")

        url_to_streams = build_url({
            "action": "streams",
            "type": item["type"],
            "imdb_id": item["imdb_id"],
            "title": item["title"]
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url_to_streams, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_streams(video_type, imdb_id, clean_title):
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    url = BASE_URL + "/api/kodi?userKey=" + USER_KEY + "&imdb_id=" + imdb_id + "&type=" + video_type
    try:
        resp = requests.get(url, timeout=15)
        data = resp.json()
    except Exception as e:
        show_error("שגיאת חיבור: " + str(e))
        return

    for stream in data.get("results", []):
        source_hint = stream.get("title", "")[:35]
        label = "[" + stream.get("quality", "SD") + "] " + clean_title
        if stream.get("sizeGB"):
            label += " (" + str(stream["sizeGB"]) + " GB)"

        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo("video", {"title": clean_title, "plot": source_hint})
        list_item.setUniqueIDs({"imdb": imdb_id}, "imdb")
        list_item.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            stream["url"],
            list_item,
            isFolder=False
        )

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def router():
    force_skin_once()
    params = get_params()
    action = params.get("action")

    if action == "type_root":
        if params["type"] == "tv":
            list_live_tv()
        else:
            list_type_root(params["type"])
    elif action == "catalog":
        list_catalog_items(params["type"], params["catalogId"])
    elif action == "streams":
        list_streams(params["type"], params["imdb_id"], params.get("title", "תוצאה"))
    else:
        list_root()


if __name__ == "__main__":
    router()