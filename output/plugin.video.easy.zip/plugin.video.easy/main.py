# main.py
# Esay Kodi Add-on - מתחבר לשרת Vercel הפרטי (kodi.js + kodi-catalog.js)
import sys
import urllib.parse
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])

# --- הגדרות קבועות: עדכן את הכתובת והמזהה האישי שלך כאן ---
BASE_URL = "https://user-manager-lime.vercel.app"
USER_KEY = "1c1bb3d3-246c-46f1-8209-bd98cf93c7bb"  # <-- כאן שם את מזהה המשתמש האישי שלך (כמו ב-manifest ל-Stremio)

xbmcplugin.setContent(ADDON_HANDLE, "movies")


def build_url(query):
    return sys.argv[0] + "?" + urllib.parse.urlencode(query)


def get_params():
    param_string = sys.argv[2][1:]
    return dict(urllib.parse.parse_qsl(param_string))


def list_catalogs():
    url = BASE_URL + "/api/kodi-catalog?userKey=" + USER_KEY + "&list=catalogs"
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
    except Exception as e:
        xbmcgui.Dialog().notification("Esay", "שגיאת חיבור: " + str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    for cat in data.get("catalogs", []):
        list_item = xbmcgui.ListItem(label=cat["name"])
        list_item.setIsFolder(True)
        url_to_catalog = build_url({
            "action": "catalog",
            "type": cat["type"],
            "catalogId": cat["id"]
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url_to_catalog, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_catalog_items(catalog_type, catalog_id):
    url = BASE_URL + "/api/kodi-catalog?userKey=" + USER_KEY + "&type=" + catalog_type + "&catalogId=" + catalog_id
    try:
        resp = requests.get(url, timeout=10)
        data = resp.json()
    except Exception as e:
        xbmcgui.Dialog().notification("Esay", "שגיאת חיבור: " + str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    for item in data.get("items", []):
        list_item = xbmcgui.ListItem(label=item["title"])
        list_item.setArt({
            "poster": item.get("poster", ""),
            "fanart": item.get("fanart", "")
        })
        list_item.setInfo("video", {
            "title": item["title"],
            "plot": item.get("plot", ""),
            "year": item.get("year", ""),
            "genre": item.get("genres", "")
        })
        if item.get("imdb_id"):
            list_item.setUniqueIDs({"imdb": item["imdb_id"]}, "imdb")

        url_to_streams = build_url({
            "action": "streams",
            "type": item["type"],
            "imdb_id": item["imdb_id"],
            "title": item["title"]
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url_to_streams, list_item, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def list_streams(video_type, imdb_id, title):
    url = BASE_URL + "/api/kodi?userKey=" + USER_KEY + "&imdb_id=" + imdb_id + "&type=" + video_type
    try:
        resp = requests.get(url, timeout=15)
        data = resp.json()
    except Exception as e:
        xbmcgui.Dialog().notification("Esay", "שגיאת חיבור: " + str(e), xbmcgui.NOTIFICATION_ERROR)
        return

    for stream in data.get("results", []):
        label = "[" + stream.get("quality", "SD") + "] " + stream["title"]
        if stream.get("sizeGB"):
            label += " (" + str(stream["sizeGB"]) + " GB)"

        list_item = xbmcgui.ListItem(label=label)
        list_item.setInfo("video", {"title": title})
        list_item.setUniqueIDs({"imdb": imdb_id}, "imdb")
        list_item.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            stream["url"],
            list_item,
            isFolder=False
        )

    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def router():
    params = get_params()
    action = params.get("action")

    if action == "catalog":
        list_catalog_items(params["type"], params["catalogId"])
    elif action == "streams":
        list_streams(params["type"], params["imdb_id"], params.get("title", ""))
    else:
        list_catalogs()


if __name__ == "__main__":
    router()